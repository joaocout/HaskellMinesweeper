ALUNOS:
Joao Pedro Assuncao Coutinho - 18/0019813
Breno Felipe N. Gomes - 16/0003318

OBSERVACOES:
Para compilar: "make" ou "make all"
Para executar: "./mines"
